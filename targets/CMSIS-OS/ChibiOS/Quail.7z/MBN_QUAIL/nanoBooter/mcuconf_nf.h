//
// Copyright (c) 2017 The nanoFramework project contributors
// See LICENSE file in the project root for full license information.
//

#ifndef _MCUCONF_NF_H_
#define _MCUCONF_NF_H_

#endif // _MCUCONF_NF_H_

